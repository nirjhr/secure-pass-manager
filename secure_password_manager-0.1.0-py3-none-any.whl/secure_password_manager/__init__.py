"""Secure Password Manager package."""
from secure_password_manager.core import PasswordManager

__version__ = "0.1.0"
__all__ = ["PasswordManager"]